chrome.commands.onCommand.addListener(function(command) {
  if (command === "translate_page") {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: pageScript
      });
    });
  }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log("Received message: ", request);
  if (request.action === "translate") {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: pageScript,
      }, () => {
        console.log("Sending response back to popup");
        sendResponse({ status: "success" });
      });
    });
    return true;
  }
});

function pageScript() {
    async function handleText(textNode) {
        let text = textNode.nodeValue;
        let url = `https://www.apertium.org/apy/translate?q=${encodeURIComponent(text)}&langpair=nno|nob`;
    
        try {
            let response = await fetch(url);
            let data = await response.json();
            if (data && data.responseData && data.responseData.translatedText) {
                let translatedText = data.responseData.translatedText.replace(/\*/g, '');
                textNode.nodeValue = translatedText;
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    function handleElement(element) {
        element.childNodes.forEach(child => {
            if (child.nodeType === 3) {
                handleText(child);
            } else if (child.nodeType === 1) {
                handleElement(child);
            }
        });
    }

    function addMutationObserver() {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) { 
                        handleElement(node);
                    }
                });
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    handleElement(document.body);
    addMutationObserver();
}