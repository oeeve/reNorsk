document.addEventListener('DOMContentLoaded', function () {
    const translateButton = document.getElementById('translateButton');
    if (translateButton) {
        translateButton.addEventListener('click', function () {
            this.classList.add('loading');

            chrome.runtime.sendMessage({ action: 'translate' }, function (response) {
                if (response && response.status === "success") {
                }
                setTimeout(() => {
                    translateButton.classList.remove('loading');
                }, 4000); // This duration should match the animation duration
            });
        });
    }
});
