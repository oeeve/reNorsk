async function u(){try{const[n]=await chrome.tabs.query({active:!0,currentWindow:!0});n&&(await chrome.scripting.executeScript({target:{tabId:n.id},func:E}),console.log("reNorsk: Language correction executed successfully on",n.url))}catch(n){console.error("reNorsk: Error executing correction:",n),chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"images/icon48.png",title:"reNorsk",message:"Rettingen ble ikke gjennomført :( Det er mulig siden du er på ikke er støttet."})}}chrome.commands.onCommand.addListener(async n=>{n==="correct_page"&&(console.log("reNorsk: Keyboard shortcut triggered"),await u())});chrome.action.onClicked.addListener(async n=>{console.log("reNorsk: Extension icon clicked"),await u()});function E(){console.log("reNorsk: Correction script started");const n=20;let e=null,i=0,d=0;function g(o){i=o,d=0;const t=document.getElementById("reNorsk-indicator");if(t&&t.remove(),e=document.createElement("div"),e.id="reNorsk-indicator",e.innerHTML=`
            <div style="display: flex; align-items: center; gap: 8px;">
                <span class="reNorsk-spinner">🇳🇴</span>
                <span class="reNorsk-text">reNorsk retter...</span>
                <span class="reNorsk-progress">0/${i}</span>
            </div>
        `,e.style.cssText=`
            position: fixed;
            top: 10px;
            right: 10px;
            background: #8BBCD2;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            z-index: 10000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        `,!document.getElementById("reNorsk-style")){const s=document.createElement("style");s.id="reNorsk-style",s.textContent=`
                @keyframes reNorsk-spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                #reNorsk-indicator .reNorsk-spinner {
                    display: inline-block;
                    animation: reNorsk-spin 1s linear infinite;
                }
            `,document.head.appendChild(s)}document.body.appendChild(e)}function m(){if(d++,e){const o=e.querySelector(".reNorsk-progress");o&&(o.textContent=`${d}/${i}`),d>=i&&setTimeout(()=>{e&&(e.querySelector(".reNorsk-text").textContent="Retting fullført! 🎉",e.querySelector(".reNorsk-spinner").textContent="🎉",e.style.background="#B5DAC0",setTimeout(()=>{e&&e.parentNode&&(e.style.opacity="0",setTimeout(()=>{e&&e.parentNode&&e.parentNode.removeChild(e)},300))},1500))},100)}}async function f(o){try{const t=o.nodeValue,r=t.trim();if(r.length<2||r.length>500||!/[a-zA-ZæøåÆØÅ]/.test(r))return;const s=`https://www.apertium.org/apy/translate?q=${encodeURIComponent(r)}&langpair=nno|nob`,a=await(await fetch(s)).json();if(a&&a.responseData&&a.responseData.translatedText){const l=a.responseData.translatedText.replace(/\*/g,"");if(l!==r){const p=t.match(/^\s*/)[0],x=t.match(/\s*$/)[0];o.nodeValue=p+l+x,console.log(`reNorsk: Rettet "${r.substring(0,30)}..."`)}}}catch(t){console.error("reNorsk: Error :(",t)}finally{m()}}async function N(o){const t=o.map(r=>f(r));await Promise.allSettled(t)}function k(){const o=[],t=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(s){const c=s.parentElement;if(!c)return NodeFilter.FILTER_REJECT;const a=c.tagName;if(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","SELECT"].includes(a)||c.contentEditable==="true")return NodeFilter.FILTER_REJECT;const l=getComputedStyle(c);if(l.display==="none"||l.visibility==="hidden")return NodeFilter.FILTER_REJECT;const p=s.nodeValue.trim();return p.length>2&&/[a-zA-ZæøåÆØÅ]/.test(p)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}});let r;for(;r=t.nextNode();)o.push(r);return o}async function y(){console.log("reNorsk: Starting language corrections");const o=k();if(i=o.length,console.log(`reNorsk: Fant ${i} tekstnoder`),i===0){console.log("reNorsk: No text nodes found to correct");return}g(i);for(let t=0;t<o.length;t+=n){const r=o.slice(t,t+n);await N(r),t+n<o.length&&await new Promise(s=>setTimeout(s,50))}console.log("reNorsk: Retting fullført!")}y()}
